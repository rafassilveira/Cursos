const v1 = 10;
function fn1() {
    console.log(v1);
};
fn1();
